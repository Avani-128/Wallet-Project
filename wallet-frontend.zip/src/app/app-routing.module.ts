import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountComponent } from './createAccount/createAccount.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { TransferComponent } from './transfer/transfer.component';
import { HomePageComponent } from './homepage/homepage.component';
import { loginComponent } from './login/login.component';
import { MainMenuComponent } from './main-menu/main-menu.component';
import { ShowBalanceComponent } from './showBalance/showBalance.component';
import { PrintTransactionsComponent } from './printTransactions/printTransactions.component';
import { TransComponent } from './trans/trans.component';


const routes: Routes = [
  {path:'', component:HomePageComponent},
  {path:'createAccount', component:CreateAccountComponent},
  {path:'login',component:loginComponent},
  {path:'main-menu',component:MainMenuComponent},
  {path:'showBalance', component:ShowBalanceComponent},
 // {path:'update',component:UpdateComponent},
  {path:'deposit', component:DepositComponent},
  {path:'withdraw',component:WithdrawComponent},
  {path:'transfer', component:TransferComponent},
 // {path:'delete',component:DeleteComponent},
  {path:'trans',component:TransComponent},
  {path:'printTransactions',component:PrintTransactionsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
