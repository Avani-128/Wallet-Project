import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { WalletService } from '../wallet.service';

@Component({
  selector: 'app-printTransactions',
  templateUrl: './printTransactions.component.html',
  styleUrls: ['./printTransactions.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class PrintTransactionsComponent implements OnInit {
result:any;
constructor(private walletService:WalletService,private router: Router) { }

  ngOnInit() {
    if(!(localStorage.username || localStorage.password))
    {
      this.router.navigate(['']);
    }
    if((localStorage.username && localStorage.password)&& !(localStorage.acc_no))
    {
      this.router.navigate(['/main-menu']);
    }
    this.transaction1();
  }

  transaction1(){
    this.walletService.printTransactions(localStorage.acc_no).subscribe(data => {
      this.result=data;
      console.log(this.result);
    },
    err =>{
      console.log(err.stack);
    })
  } 

  do(){
    
    this.router.navigate(['/main-menu']);
  }

}