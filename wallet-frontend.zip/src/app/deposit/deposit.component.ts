import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { WalletService } from '../wallet.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class DepositComponent implements OnInit {

  submitted: boolean=false;
  depositForm: FormGroup;
  msg:any;
  msg2:any;
  message:string;
  errormsg:string;
  constructor(private formBuilder: FormBuilder,private _walletService:WalletService,private router: Router) { }

  ngOnInit() {
    this.depositForm=this.formBuilder.group({
      acc_no:['',[Validators.required,Validators.min(1)]],
      amount:['',[Validators.required,Validators.min(1)]]
    });
  }
  deposit(){
    this.submitted=true;
    if(this.depositForm.invalid)
    {
      return;
    }
    else{
      let acc_no1=this.depositForm.controls.acc_no.value;
      let amount1=this.depositForm.controls.amount.value;
      this._walletService.validatePassword(this.depositForm.controls.acc_no.value, localStorage.password).subscribe(data1 => {
        this.msg=data1;
        if(this.msg==true)
        {
          this._walletService.deposit(acc_no1,amount1).subscribe(data2 => {
            this.msg2 = data2;
            if(this.msg2==true){
            this.message="Rs"+amount1+" deposited successfully from Account Number: "+acc_no1;
            alert(this.message);
            this.router.navigate(['/main-menu']);
            }
          },
          err=>{
            console.log(err.stack);
          });
        }
        else{
          alert('Sorry! Account Details not correct');
        }
      },
        err =>{
          this.errormsg=err.error;
      alert(this.errormsg);
        });
    }
  }
  do(){
    this.router.navigate(['main-menu']);
  }

}