import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpErrorResponse } from "@angular/common/http";
import { Observable, ObservableLike, throwError } from "rxjs";
import {catchError} from 'rxjs/operators';
import { Person } from './person';
import { Transactions } from './transactions';

@Injectable({
    providedIn: 'root'
  })
  export class WalletService {
    private Url = "http://localhost:3111/spring";
    person: Person;
    transaction: Transactions;

    constructor(private http: HttpClient){}

    getAllAccounts(): Observable<Object>{
        return this.http.get<Person[]>(`${this.Url}/accounts`);
    }

    getAccountById(acc_no: number): Observable<Object>{
        return this.http.get<Person>(`${this.Url}/account/${acc_no}`);
    }

    createAccount(person: Object): Observable<Object>{
        return this.http.post<number>(`${this.Url}/add`,person);
    }

    showBalance(acc_no: number): Observable<Object>{
        return this.http.get<number>(`${this.Url}/showBalance/${acc_no}`);
    }

    deposit(acc_no: number, amount:number):Observable<Object>{
        return this.http.get<boolean>(`${this.Url}/deposit/${acc_no}/${amount}`);
    }

    withdraw(acc_no: number, amount: number): Observable<Object>{
        return this.http.get<boolean>(`${this.Url}/withdraw/${acc_no}/${amount}`).pipe(catchError(this.handleError));
    }

    transfer(acc_no1: number, acc_no2: number, amount: number): Observable<Object>{
        return this.http.get<boolean>(`${this.Url}/transfer/${acc_no1}/${acc_no2}/${amount}`).pipe(catchError(this.handleError));
    }

    printTransactions(acc_no: number): Observable<Object>{
        return this.http.get<Transactions[]>(`${this.Url}/printTransactions/${acc_no}`);
    }

    validateAccount(acc_no: number): Observable<Object>{
        return this.http.get<boolean>(`${this.Url}/validateAccount/${acc_no}`);
    }
    
    validatePassword(acc_no: number, password: string): Observable<Object>{
        return this.http.get<boolean>(`${this.Url}/validate/${acc_no}/${password}`).pipe(catchError(this.handleError));
    }

    update(person: Object): Observable<Object>{
        return this.http.put<boolean>(`${this.Url}/update`,person);
    }

    delete(acc_no: number): Observable<Object>{
        return this.http.get<boolean>(`${this.Url}/delete/${acc_no}`);
    }

    private handleError(errorResponse:HttpErrorResponse){
        return throwError(errorResponse);
      }

  }