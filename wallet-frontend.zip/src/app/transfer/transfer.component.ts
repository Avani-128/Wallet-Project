import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { WalletService } from '../wallet.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TransferComponent implements OnInit {

  submitted: boolean=false;
  transferForm: FormGroup;
  msg1:any;
  msg2:any;
  message:string;
  errormsg:string;
  constructor(private formBuilder: FormBuilder,private walletService:WalletService,private router: Router) { }

  ngOnInit() {
    this.transferForm=this.formBuilder.group({
      acc_no1:['',[Validators.required,Validators.min(1)]],
      acc_no2:['',[Validators.required,Validators.min(1)]],
      amount:['',[Validators.required,Validators.min(1)]]
    });
  }
  transfer(){
    this.submitted=true;
    if(this.transferForm.invalid)
    {
      return;
    }
    else{
      let acc_no1=this.transferForm.controls.acc_no1.value;
      let acc_no2=this.transferForm.controls.acc_no2.value;
      let amount1=this.transferForm.controls.amount.value;
      this.walletService.validatePassword(this.transferForm.controls.acc_no1.value,localStorage.password).subscribe(data1 => {
        this.msg1=data1;
        if(this.msg1==true)
        {
      this.walletService.transfer(acc_no1,acc_no2,amount1).subscribe(data2 => {
        this.msg2=data2;
        if(this.msg2==true){
        this.message="Rs. "+amount1+" transferred successfully to Account Number: "+acc_no2;
        alert(this.message);
        this.router.navigate(['/main-menu']);}
      },
      err=>{
        this.errormsg=err.error;
        alert(this.errormsg);
      });
    }
    else{
      alert('Sorry! Account Details not correct');
    }
    },
    err =>{
      this.errormsg=err.error;
      alert(this.errormsg);
    });
    }
  }

  do(){
    
    this.router.navigate(['main-menu']);
  }

}