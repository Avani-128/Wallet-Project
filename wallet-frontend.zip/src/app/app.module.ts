import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { WalletService } from './wallet.service';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { TransferComponent } from './transfer/transfer.component';
import { CreateAccountComponent } from './createAccount/createAccount.component';
import { HomePageComponent } from './homepage/homepage.component';
import { loginComponent } from './login/login.component';
import { MainMenuComponent } from './main-menu/main-menu.component';
import { ShowBalanceComponent } from './showBalance/showBalance.component';
import { TransComponent } from './trans/trans.component';
import { PrintTransactionsComponent } from './printTransactions/printTransactions.component';

@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    CreateAccountComponent,
    loginComponent,
    MainMenuComponent,
    ShowBalanceComponent,
    DepositComponent,
    WithdrawComponent,
    TransferComponent,
    TransComponent,
    PrintTransactionsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [WalletService],
  bootstrap: [AppComponent]

})
export class AppModule { }
