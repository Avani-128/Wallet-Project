import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Person } from '../person';
import { WalletService } from '../wallet.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class loginComponent implements OnInit {

  submitted: boolean=false;
  loginForm: FormGroup;
  msg:any;
  message:string;
  invalidLogin: boolean=false;
  errormsg:string;
  constructor(private formBuilder: FormBuilder,private _walletService:WalletService,private router: Router) { }


  ngOnInit() {
    if(localStorage.password || localStorage.acc_no){
     // localStorage.removeItem("username");
      localStorage.removeItem("password");
      localStorage.removeItem("acc_no");
    }
    this.loginForm=this.formBuilder.group({
      acc_no:['',[Validators.required,Validators.min(1)]],
      password:['',Validators.required]
    });
  }

  login(){
    this.submitted=true;
    if(this.loginForm.invalid){
      return;
    }

    let acc_no1=this.loginForm.controls.acc_no.value;
    let password1=this.loginForm.controls.password.value;
    localStorage.acc_no=acc_no1;
    localStorage.password=password1;

    this._walletService.validatePassword(acc_no1,password1).subscribe(data => {
      this.msg=data;
      if(this.msg==true)
      {
        localStorage.acc_no=acc_no1;
        this.router.navigate(['/main-menu']);
      }
      else{
        this.invalidLogin=true;
      }
    },
    err => {
      this.errormsg=err.error;
      alert(this.errormsg);
    });
  }
}