import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { WalletService } from '../wallet.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-showBalance',
  templateUrl: './showBalance.component.html',
  styleUrls: ['./showBalance.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ShowBalanceComponent implements OnInit {

  submitted: boolean=false;
  balanceForm: FormGroup;
  msg1:any;
  message:any;
  errormsg:string;
  constructor(private formBuilder: FormBuilder,private walletService:WalletService,private router: Router) { }

  ngOnInit() {
    this.balanceForm=this.formBuilder.group({
      acc_no:['',[Validators.required,Validators.min(1)]]
    });
  }
  balance(){
    this.submitted=true;
    if(this.balanceForm.invalid)
    {
      return;
    }
    else{
      let acc_no1=this.balanceForm.controls.acc_no.value;
      this.walletService.validatePassword(this.balanceForm.controls.acc_no.value, localStorage.password).subscribe(data1 => {
        this.msg1=data1;
        if(this.msg1==true)
        {
      this.walletService.showBalance(acc_no1).subscribe(data2 => {
        this.message=data2;
        alert("Rs."+this.message);
        this.router.navigate(['main-menu']);
      },
      err=>{
        console.log(err.stack);
      });
    }
    else{
      alert('Sorry! Account Details not correct');
    }
    },
    err =>{
      this.errormsg=err.error;
      alert(this.errormsg);
    });
    }
  }

  do(){
    
    this.router.navigate(['main-menu']);
  }


}