import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { WalletService } from '../wallet.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-trans',
  templateUrl: './trans.component.html',
  styleUrls: ['./trans.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class TransComponent implements OnInit {

  submitted: boolean=false;
  transactionForm: FormGroup;
  msg1:any;
  errormsg:string;
  message:any;
  constructor(private formBuilder: FormBuilder,private walletService:WalletService,private router: Router) { }

  ngOnInit() {
    if(!(localStorage.username || localStorage.password))
    {
      this.router.navigate(['']);
    }
    this.transactionForm=this.formBuilder.group({
      acc_no:['',[Validators.required,Validators.min(1)]]
    });
  }
  transaction(){
    this.submitted=true;
    if(this.transactionForm.invalid)
    {
      return;
    }
    else{
     
      this.walletService.validatePassword(this.transactionForm.controls.acc_no.value, localStorage.password).subscribe(data => {
        this.msg1=data;
        if(this.msg1==true){
          localStorage.acc_no=this.transactionForm.controls.acc_no.value;
          this.router.navigate(['/printTransactions']);
        }
        else{
          alert('Sorry!! Account Number is not correct');
        }
    },
    err =>{
      this.errormsg=err.error;
      alert(this.errormsg);
    });
  }

}
do(){
    
  this.router.navigate(['/main-menu']);
}
}