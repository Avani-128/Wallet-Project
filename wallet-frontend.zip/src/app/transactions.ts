export class Transactions{
    trans_Id: any;
    amount: any;
    Dest_acc: number;
    Send_acc:number;
    dates: string;
    time: string;
    type: string;
}