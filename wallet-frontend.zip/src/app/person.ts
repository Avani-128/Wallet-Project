export class Person{
    acc_no: number;
    name: string;
    email: string;
    mobile: string;
    address: string;
    username: string;
    password: string;
    balance: number;
    active: boolean;
    //constructor(name, email, mobile, address, username, password){}
}