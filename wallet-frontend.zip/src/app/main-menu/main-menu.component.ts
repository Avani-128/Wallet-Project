import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { WalletService } from '../wallet.service';
import { Router } from '@angular/router';
import { Person } from '../person';

@Component({
  selector: 'app-main-menu',
  templateUrl: './main-menu.component.html',
  styleUrls: ['./main-menu.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class MainMenuComponent implements OnInit {
  result:any;
 // p: Person = new Person();
  constructor(private _walletService:WalletService,private router: Router) { }

  ngOnInit() {
    this.transaction();
  }

  transaction(){
    this._walletService.getAccountById(localStorage.acc_no).subscribe(data => {
      this.result=data;
      //this.p = this.result;
    },
    err =>{
      console.log(err.stack);
    })
  }
  
  do(){
    localStorage.removeItem("localStorage.acc_no");
    this.router.navigate(['']);
  }
}