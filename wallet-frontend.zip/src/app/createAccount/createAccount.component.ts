import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { Person } from '../person';
import { WalletService } from '../wallet.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-createAccount',
  templateUrl: './createAccount.component.html',
  styleUrls: ['./createAccount.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CreateAccountComponent implements OnInit {

  person:Person = new Person();
  submitted=false;
  createForm : FormGroup;
  message: any;
  check = false;
  constructor(private formBuilder: FormBuilder,private _walletService:WalletService, private router:Router) { }

 
  ngOnInit() {
    this.createForm=this.formBuilder.group({
      name:['',Validators.required],
      email:['',Validators.required],
      mobile:['',Validators.required],
      address:['',Validators.required],
      username:['',Validators.required],
      password:['',Validators.required]
    });
  }

  newPerson(): void{
    this.submitted = false;
    this.person = new Person();
  }
  save(){
    this.submitted = true;
   if(this.createForm.invalid)
    return;
    else{
      this.check = true;
    this._walletService.createAccount(this.person).subscribe(data=> { console.log(data);
      this.person=new Person();
      this.message=data;
          alert("Account Number generated as: "+this.message);
      this.router.navigate(['/login']);
    }, 
    err => 
    { console.log(err.stack);
    });
}
}

onSubmit(){ 
 // this.submitted = true;
  this.save();
} 

}