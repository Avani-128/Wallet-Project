import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { WalletService } from '../wallet.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class WithdrawComponent implements OnInit {

  submitted: boolean=false;
  withdrawForm: FormGroup;
  msg:any;
  msg2:any;
  message:string;
  errormsg:string;
  constructor(private formBuilder: FormBuilder,private _walletService:WalletService,private router: Router) { }

  ngOnInit() {
    this.withdrawForm=this.formBuilder.group({
      acc_no:['',[Validators.required,Validators.min(1)]],
      amount:['',[Validators.required,Validators.min(1)]]
    });
  }
  withdraw(){
    this.submitted=true;
    if(this.withdrawForm.invalid)
    {
      return;
    }
    else{
      let acc_no1=this.withdrawForm.controls.acc_no.value;
      let amount1=this.withdrawForm.controls.amount.value;
      this._walletService.validatePassword(this.withdrawForm.controls.acc_no.value, localStorage.password).subscribe(data1 => {
        this.msg=data1;
        if(this.msg==true)
        {
      this._walletService.withdraw(acc_no1,amount1).subscribe(data2 => {
        this.msg2=data2;
        if(this.msg2==true){
        this.message="Rs"+amount1+" withdrawn successfully from Account Number: "+acc_no1;
        alert(this.message);
        this.router.navigate(['main-menu']);
        }
      },
      err=>{
        this.errormsg=err.error;
      alert(this.errormsg);
      });
    }
    else{
      alert('Sorry! Account Details not correct');
    }
    },
    err =>{
      this.errormsg=err.error;
      alert(this.errormsg);
    });
    }
  }

  do(){
    
    this.router.navigate(['main-menu']);
  }

}