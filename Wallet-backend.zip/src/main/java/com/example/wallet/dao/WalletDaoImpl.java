package com.example.wallet.dao;

import java.sql.*;
import java.util.*;

import javax.persistence.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.example.wallet.entity.Person;
import com.example.wallet.entity.TransactionRecord;

@Repository
@EnableTransactionManagement
public class WalletDaoImpl implements WalletDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	@PersistenceContext
	EntityManager em;
	
	private static final Double DOUBLE = (Double) null;
	
	@Override
	public List<Person> getAllAccounts() {
		String AccSelect = "select p.acc_no, p.address, p.balance, p.email, p.mobile, p.name, p.password, p.username from walletperson p";
		List<Person> acts = jdbcTemplate.query(AccSelect, new RowMapper<Person>() {
			public Person mapRow(ResultSet rs, int rowNum) throws SQLException, DataAccessException{
				Person p = new Person();
				p.setAccNo(rs.getLong(1));
				p.setAddress(rs.getString(2));
				p.setBalance(rs.getDouble(3));
				p.setEmail(rs.getString(4));
				p.setMobile(rs.getString(5));
				p.setName(rs.getString(6));
				p.setPassword(rs.getString(7));
				p.setUsername(rs.getString(8));
				return p;
			}
		});
		return acts;
	}

	@Override
	public Person getAccountById(long accNo) {
		try {
		Person p = em.find(Person.class, accNo);
		return p;
		}
		catch(Exception e) {
			return null;
		}
	}

	@Override
	public long createAccount(Person p) {
		em.persist(p);
		return p.getAccNo();
	}

	@Override
	public boolean Update(Person p) {
		/*long ac = p.getAccNo();
		Person p1 = em.find(Person.class, ac);
		p1.setAddress(p.getAddress());
		p1.setEmail(p.getEmail());
		p1.setMobile(p.getMobile());
		p1.setName(p.getName());
		p1.setPassword(p.getPassword());
		p1.setUsername(p.getUsername());*/
		em.merge(p);
		return true;
	}

	@Override
	public double showBalance(long accNo) {
		try {
		Person pr = em.find(Person.class, accNo);
		return pr.getBalance();
		}
		catch(Exception e) {
			return DOUBLE;
		}
		
	}

	@Override
	public boolean deposit(long accNo, double amount) {
		Person pr = em.find(Person.class, accNo);
		pr.setBalance(pr.getBalance() + amount);
		TransactionRecord tr = new TransactionRecord();
		long tran = (long) ((long) 10000 * Math.random());
		tr.setTransId(tran);
		tr.setAmount(amount);
		tr.setDest_acc(accNo);
		tr.setType("Credit");
		tr.setSend_acc(accNo);
		em.persist(tr);
		return true;
	}

	@Override
	public boolean withdraw(long accNo, double amount) {
		Person pr = em.find(Person.class, accNo);
		if(pr.getBalance() >= amount) {
		pr.setBalance(pr.getBalance() - amount);
		TransactionRecord tr = new TransactionRecord();
		long tran = (long) ((long) 10000 * Math.random());
		tr.setTransId(tran);
		tr.setAmount(amount);
		tr.setDest_acc(accNo);
		tr.setType("Debit");
		tr.setSend_acc(accNo);
		em.persist(tr);
		return true;
		}
		return false;
	}

	@Override
	public boolean transfer(long accNo1, long accNo2, double amount) {
		
		Person pr1 = em.find(Person.class, accNo1);
		if(pr1.getBalance() >= amount) {
		pr1.setBalance(pr1.getBalance() - amount);
		TransactionRecord tr1 = new TransactionRecord();
		long tran1 = (long) ((long) 10000 * Math.random());
		tr1.setTransId(tran1);
		tr1.setAmount(amount);
		tr1.setDest_acc(accNo2);
		tr1.setType("Debit");
		tr1.setSend_acc(accNo1);
		em.persist(tr1);
		
		Person pr2 = em.find(Person.class, accNo2);
		pr2.setBalance(pr2.getBalance() + amount);
		TransactionRecord tr2 = new TransactionRecord();
		long tran2 = (long) ((long) 10000 * Math.random());
		tr2.setTransId(tran2);
		tr2.setAmount(amount);
		tr2.setDest_acc(accNo2);
		tr2.setType("Credit");
		tr2.setSend_acc(accNo1);
		em.persist(tr2);
		
		return true;
		}
		return false;
	}

	@Override
	public List<TransactionRecord> printTransactions(long accNo) {
		List<TransactionRecord> trans = this.jdbcTemplate.query(
		        "select trans_id, amount, dates, dest_acc, send_acc, time, type from Transactions where send_acc = ?",
		        new RowMapper<TransactionRecord>() {
		            public TransactionRecord mapRow(ResultSet rs, int rowNum) throws SQLException, DataAccessException {
		                TransactionRecord trc = new TransactionRecord();
		                trc.setTransId(rs.getLong(1));
		                trc.setAmount(rs.getDouble(2));
		                trc.setDates(rs.getString(3));
		                trc.setDest_acc(rs.getLong(4));
		                trc.setSend_acc(rs.getLong(5));
		                trc.setTime(rs.getString(6));
		                trc.setType(rs.getString(7));
		                return trc;
		            }
		        },accNo);
		return trans;
		/*
		List<TransactionRecord> trans = em.createQuery(
				    "select t " + "from Transactions t " + "where t.acc_no in (:acc_no)", TransactionRecord.class)
				.setParameter( "acc_no").getResultList();
				return trans;*/
	}

	@Override
	public boolean Delete(long accNo) {
		/*String del = "delete from walletperson p where p.acc_no=?";
		jdbcTemplate.update(del, accNo);*/
		/*
		 	Query query = em.createNativeQuery("DELETE FROM WALLETPERSON WHERE acc_no = " + acc_no);
			query.executeUpdate();
		 */
		Person p = em.find(Person.class, accNo);
		em.remove(p);
		return true;
	}

	@Override
	public boolean validateAccount(long acc_no) {
		try{
			Person p = em.find(Person.class, acc_no);
		if(acc_no==p.getAccNo() && p!=null) {
			return true;
			}
		else return false;
		}
		catch(Exception e) {
			return false;
		}
	}

	@Override
	public boolean validatePassword(long acc_no, String password) {
		try{
			Person p = em.find(Person.class, acc_no);
		if(acc_no==p.getAccNo() && p.getPassword().equals(password) && p!=null) {
			return true;
			}
		else return false;
		}
		catch(Exception e) {
			return false;
		}
	}
}