package com.example.wallet.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.wallet.dao.WalletDao;
import com.example.wallet.dao.WalletDaoImpl;
import com.example.wallet.entity.Person;
import com.example.wallet.entity.TransactionRecord;

@Service
@Transactional
public class WalletServiceImpl implements WalletService {
	
	@Autowired
	WalletDao walDao;

	public WalletServiceImpl() {
		walDao = new WalletDaoImpl();
	}

	@Override
	public List<Person> getAllAccounts() {
		return walDao.getAllAccounts();
	}

	@Override
	public Person getAccountById(long accNo) {
		return walDao.getAccountById(accNo);
	}

	@Override
	public long createAccount(Person p) {
		return walDao.createAccount(p);
	}

	@Override
	public boolean Update(Person p) {
		return walDao.Update(p);
	}

	@Override
	public double showBalance(long accNo) {
		return walDao.showBalance(accNo);
	}

	@Override
	public boolean deposit(long accNo, double amount) {
		return walDao.deposit(accNo, amount);
	}

	@Override
	public boolean withdraw(long accNo, double amount) {
		return walDao.withdraw(accNo, amount);
	}

	@Override
	public boolean transfer(long accNo1, long accNo2, double amount) {
		return walDao.transfer(accNo1, accNo2, amount);
	}

	@Override
	public List<TransactionRecord> printTransactions(long accNo) {
		return walDao.printTransactions(accNo);
	}

	@Override
	public boolean Delete(long accNo) {
		return walDao.Delete(accNo);
	}

	@Override
	public boolean validateAccount(long acc_no) {
		Person p = walDao.getAccountById(acc_no);
		if (p != null)
			return true;
		return false;
	}

	@Override
	public boolean validatePassword(long acc_no, String password) {
		return walDao.validatePassword(acc_no,password);
	}
	
	
}
