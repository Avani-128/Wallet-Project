package com.example.wallet.services;

import java.util.List;

import com.example.wallet.entity.Person;
import com.example.wallet.entity.TransactionRecord;

public interface WalletService {
	
	public List<Person> getAllAccounts();
	public Person getAccountById(long accNo);
	public long createAccount(Person p);
	public boolean Update(Person p);
	public double showBalance(long accNo);
	public boolean deposit(long accNo, double amount);
	public boolean withdraw(long accNo, double amount);
	public boolean transfer(long accNo1, long accNo2, double amount);
	public List<TransactionRecord> printTransactions(long accNo);
	public boolean Delete(long accNo);
	
	public boolean validateAccount(long acc_no);
	public boolean validatePassword(long acc_no, String password);
}
