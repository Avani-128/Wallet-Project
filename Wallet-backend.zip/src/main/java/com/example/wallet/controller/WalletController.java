package com.example.wallet.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.wallet.entity.Person;
import com.example.wallet.entity.TransactionRecord;
import com.example.wallet.services.WalletService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/spring")
public class WalletController {
	
	@Autowired
	WalletService walService;
	
	@GetMapping("/accounts")
	public List<Person> getAllAccounts(){
		return walService.getAllAccounts();
	}
	
	@GetMapping("/account/{acc_no}")
	public Person getAccountById(@PathVariable Long acc_no) {
		return walService.getAccountById(acc_no);
	}
	
	@PostMapping("/add")
	public long createAccount(@RequestBody Person p) {
		  Person p1 = p;
		  p1.setAccNo(0);
		  p1.setAddress(p.getAddress());
		  p1.setBalance(0);
		  p1.setEmail(p.getEmail());
		  p1.setMobile(p.getMobile());
		  p1.setName(p.getName()); 
		  p1.setPassword(p.getPassword());
		  p1.setUsername(p.getUsername());
		return walService.createAccount(p);
	}
	
	@PutMapping("/update")
	public boolean Update(@RequestBody Person p) {
		Person p1 = walService.getAccountById(p.getAccNo());
		p1.setAddress(p.getAddress());
		p1.setBalance(p.getBalance());
		p1.setEmail(p.getEmail());
		p1.setMobile(p.getMobile());
		p1.setName(p.getName());
		p1.setPassword(p.getPassword());
		p1.setUsername(p.getUsername());
        return walService.Update(p);
	}
	
	@GetMapping("/showBalance/{acc_no}")
	public Double showBalance(@PathVariable Long acc_no) {
		return walService.showBalance(acc_no);
	}
	
	@GetMapping("/deposit/{acc_no}/{amount}")
	public boolean deposit(@PathVariable Long acc_no, @PathVariable Double amount) {
		return walService.deposit(acc_no, amount);
	}
	
	@GetMapping("/withdraw/{acc_no}/{amount}")
	public boolean withdraw(@PathVariable Long acc_no, @PathVariable Double amount) {
		return walService.withdraw(acc_no, amount);
	}
	
	@GetMapping("/transfer/{acc_no}/{dest_acc}/{amount}")
	public boolean transfer(@PathVariable Long acc_no, @PathVariable Long dest_acc, @PathVariable Double amount) {
		return walService.transfer(acc_no, dest_acc, amount);
	}
	
	@GetMapping("/printTransactions/{acc_no}")
	public List<TransactionRecord> printTransactions(@PathVariable Long acc_no) {
		return walService.printTransactions(acc_no);
	}
	
	@DeleteMapping("/delete/{acc_no}")
	public boolean Delete(@PathVariable Long accNo) {
		return walService.Delete(accNo);
		
	}
	
	@GetMapping("/validate/{acc_no}/{password}")
	public boolean validatePassword(@PathVariable Long acc_no,  @PathVariable String password) {
		return walService.validatePassword(acc_no, password);
	}

	@GetMapping("/validateAccount/{acc_no}")
	public boolean validateAccount(@PathVariable Long acc_no) {
		return walService.validateAccount(acc_no);
	}
	
}
