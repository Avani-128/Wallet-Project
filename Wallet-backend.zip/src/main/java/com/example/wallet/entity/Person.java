package com.example.wallet.entity;

import java.io.Serializable;
import java.util.Random;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "walletperson")
public class Person implements Serializable{
	
	private static final long serialVersionUID = 1L;
	@Id
	private long acc_no;
	private String address;
	private double balance;
	private String email;
	private String mobile;
	private String name;
	private String password;
	private String username;
	
	public Person() {
	}

	public Person(long acc_no, String address, double balance, String email, String mobile, String name,
			String password, String username) {
		super();
		Random r = new Random();
		this.acc_no =(long) r.nextInt(100000);
		this.balance = 0;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.address = address;
		this.username = username;
		this.password = password;
	}
	

	public long getAccNo() {
		return acc_no;
	}

	public void setAccNo(long acc_no) {
		Random r = new Random();
		this.acc_no = (long) r.nextInt(100000);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}