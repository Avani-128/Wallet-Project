package com.example.wallet.entity;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="transactions")
public class TransactionRecord {
	@Id
	private long trans_id;
	private double amount;
	private String dates;
	private long send_acc;
	private long dest_acc;
	private String time;
	private String type;
	
	@Transient
	LocalDate d;
	@Transient
	LocalTime t;
	
	public TransactionRecord() {
		this.d = LocalDate.now(); 
		this.t = LocalTime.now(); 
		this.dates = d.toString(); 
		this.time = t.toString();
	}
	public TransactionRecord(long transId, double amount, String dates, long dest_acc, String time, String type, long send_acc) {
		super();
		this.trans_id = transId;
		this.amount = amount;
		this.dest_acc = dest_acc;
		d = LocalDate.now();
		t = LocalTime.now();
		this.dates = d.toString(); 
		this.time = t.toString();
		this.type = type;
		this.send_acc = send_acc;
	}
	public long getTransId() {
		return trans_id;
	}
	public void setTransId(long transId) {
		this.trans_id = transId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public long getDest_acc() {
		return dest_acc;
	}
	public void setDest_acc(long dest_acc) {
		this.dest_acc = dest_acc;
	}
	public String getDates() {
		return dates;
	}
	public void setDates(String dates) {
		this.dates = dates;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public long getSend_acc() {
		return send_acc;
	}
	public void setSend_acc(long send_acc) {
		this.send_acc = send_acc;
	}
	
}
